import { v } from "convex/values";
import { mutation, query } from "./typeFunctions";
import {
  briefFields,
  captionFields,
  formatType,
  hookType,
  projectFields,
  sceneInputFields,
  timelapseFields,
} from "./schema";

const MAX_TEXT = 8000;
const MAX_SCENES = 12;
const MAX_HOOKS = 20;
const MAX_QC = 60;

function assertText(value: string, name: string, max = MAX_TEXT) {
  if (typeof value !== "string" || value.length > max) {
    throw new Error(`${name} quá dài (tối đa ${max} ký tự)`);
  }
}
function assertNum(value: number, name: string, min: number, max: number) {
  if (!Number.isFinite(value) || value < min || value > max) {
    throw new Error(`${name} không hợp lệ`);
  }
}

type SceneInput = {
  order: number;
  startSec: number;
  endSec: number;
  role: string;
  hero: boolean;
  shotSize: "toan" | "trung" | "can";
  camera: "push_in" | "pull_out" | "pan" | "tilt" | "static";
  action: string;
  subject: string;
  environment: string;
  prop: string;
  animal: string;
  screenLayout: "none" | "ots" | "front" | "pip";
  voiceover: string;
  label: string;
  promptOverride: string;
  status: { keyframe: boolean; take: boolean; approved: boolean; assembled: boolean };
  takes: number;
  note: string;
};

function validateScene(s: SceneInput) {
  assertNum(s.order, "Thứ tự cảnh", 0, MAX_SCENES);
  assertNum(s.startSec, "Giây bắt đầu", 0, 600);
  assertNum(s.endSec, "Giây kết thúc", 0, 600);
  if (s.endSec <= s.startSec) throw new Error("Giây kết thúc phải lớn hơn giây bắt đầu");
  assertNum(s.takes, "Số take", 1, 3);
  for (const key of [
    "role",
    "action",
    "subject",
    "environment",
    "prop",
    "animal",
    "voiceover",
    "label",
    "promptOverride",
    "note",
  ] as const) {
    assertText(s[key], key);
  }
}

function validateBrief(b: { audience: string; pain: string; angle: string; evidence: string; cta: string }) {
  for (const key of ["audience", "pain", "angle", "evidence", "cta"] as const) assertText(b[key], key);
}
function validateCaption(c: { hook: string; body: string; cta: string; hashtags: string }) {
  for (const key of ["hook", "body", "cta", "hashtags"] as const) assertText(c[key], key);
}
function validateTimelapse(t: { boiCanh: string; vatNeo: string; kienTruc: string; chu: string }) {
  for (const key of ["boiCanh", "vatNeo", "kienTruc", "chu"] as const) assertText(t[key], key);
}

const sceneDoc = v.object({
  _id: v.id("scenes"),
  _creationTime: v.number(),
  projectId: v.id("projects"),
  ...sceneInputFields,
});
const projectDoc = v.object({
  _id: v.id("projects"),
  _creationTime: v.number(),
  ...projectFields,
});

export const status = query({
  args: {},
  returns: v.object({ ready: v.boolean() }),
  handler: async () => ({ ready: true }),
});

export const listProjects = query({
  args: {},
  returns: v.array(
    v.object({
      _id: v.id("projects"),
      title: v.string(),
      format: formatType,
      durationSec: v.number(),
      updatedAt: v.number(),
    }),
  ),
  handler: async (ctx) => {
    const rows = await ctx.db.query("projects").withIndex("by_updated").order("desc").take(50);
    return rows.map((p) => ({
      _id: p._id,
      title: p.title,
      format: p.format,
      durationSec: p.durationSec,
      updatedAt: p.updatedAt,
    }));
  },
});

export const getProject = query({
  args: { projectId: v.id("projects") },
  returns: v.union(v.null(), v.object({ project: projectDoc, scenes: v.array(sceneDoc) })),
  handler: async (ctx, { projectId }) => {
    const project = await ctx.db.get(projectId);
    if (!project) return null;
    const scenes = await ctx.db
      .query("scenes")
      .withIndex("by_project", (q) => q.eq("projectId", projectId))
      .take(MAX_SCENES + 4);
    return { project, scenes };
  },
});

export const createProject = mutation({
  args: {
    title: v.string(),
    format: formatType,
    durationSec: v.number(),
    timelapse: v.optional(v.object(timelapseFields)),
    scenes: v.array(v.object(sceneInputFields)),
    now: v.number(),
  },
  returns: v.id("projects"),
  handler: async (ctx, args) => {
    assertText(args.title, "Tiêu đề", 200);
    if (!args.title.trim()) throw new Error("Cần tiêu đề dự án");
    assertNum(args.durationSec, "Thời lượng", 5, 600);
    assertNum(args.now, "Thời gian", 0, 4102444800000);
    if (args.scenes.length > MAX_SCENES) throw new Error(`Tối đa ${MAX_SCENES} cảnh`);
    args.scenes.forEach(validateScene);
    const timelapse = args.timelapse ?? { boiCanh: "", vatNeo: "", kienTruc: "", chu: "" };
    validateTimelapse(timelapse);

    const projectId = await ctx.db.insert("projects", {
      title: args.title.trim(),
      format: args.format,
      durationSec: args.durationSec,
      brief: { audience: "", pain: "", angle: "", evidence: "", cta: "" },
      hooks: [],
      selectedHook: -1,
      characterBible: "",
      timelapse,
      caption: { hook: "", body: "", cta: "", hashtags: "" },
      qc: [],
      createdAt: args.now,
      updatedAt: args.now,
    });
    for (const scene of args.scenes) {
      await ctx.db.insert("scenes", { projectId, ...scene });
    }
    return projectId;
  },
});

export const updateProject = mutation({
  args: {
    projectId: v.id("projects"),
    now: v.number(),
    patch: v.object({
      title: v.optional(v.string()),
      brief: v.optional(v.object(briefFields)),
      hooks: v.optional(v.array(v.object({ type: hookType, text: v.string() }))),
      selectedHook: v.optional(v.number()),
      characterBible: v.optional(v.string()),
      timelapse: v.optional(v.object(timelapseFields)),
      caption: v.optional(v.object(captionFields)),
      qc: v.optional(v.array(v.string())),
    }),
  },
  returns: v.null(),
  handler: async (ctx, { projectId, patch, now }) => {
    const project = await ctx.db.get(projectId);
    if (!project) throw new Error("Không tìm thấy dự án");
    assertNum(now, "Thời gian", 0, 4102444800000);
    if (patch.title !== undefined) {
      assertText(patch.title, "Tiêu đề", 200);
      if (!patch.title.trim()) throw new Error("Tiêu đề không được rỗng");
    }
    if (patch.brief) validateBrief(patch.brief);
    if (patch.hooks) {
      if (patch.hooks.length > MAX_HOOKS) throw new Error(`Tối đa ${MAX_HOOKS} hook`);
      patch.hooks.forEach((h) => assertText(h.text, "Hook", 600));
    }
    if (patch.selectedHook !== undefined) {
      assertNum(patch.selectedHook, "Hook được chọn", -1, MAX_HOOKS);
    }
    if (patch.characterBible !== undefined) assertText(patch.characterBible, "Character bible");
    if (patch.timelapse) validateTimelapse(patch.timelapse);
    if (patch.caption) validateCaption(patch.caption);
    if (patch.qc) {
      if (patch.qc.length > MAX_QC) throw new Error("Danh sách QC quá dài");
      patch.qc.forEach((k) => assertText(k, "QC key", 80));
    }
    await ctx.db.patch(projectId, { ...patch, updatedAt: now });
    return null;
  },
});

export const updateScene = mutation({
  args: {
    sceneId: v.id("scenes"),
    now: v.number(),
    patch: v.object({
      role: v.optional(v.string()),
      hero: v.optional(v.boolean()),
      shotSize: v.optional(sceneInputFields.shotSize),
      camera: v.optional(sceneInputFields.camera),
      action: v.optional(v.string()),
      subject: v.optional(v.string()),
      environment: v.optional(v.string()),
      prop: v.optional(v.string()),
      animal: v.optional(v.string()),
      screenLayout: v.optional(sceneInputFields.screenLayout),
      voiceover: v.optional(v.string()),
      label: v.optional(v.string()),
      promptOverride: v.optional(v.string()),
      status: v.optional(sceneInputFields.status),
      takes: v.optional(v.number()),
      note: v.optional(v.string()),
    }),
  },
  returns: v.null(),
  handler: async (ctx, { sceneId, patch, now }) => {
    const scene = await ctx.db.get(sceneId);
    if (!scene) throw new Error("Không tìm thấy cảnh");
    assertNum(now, "Thời gian", 0, 4102444800000);
    const merged = { ...scene, ...patch };
    validateScene(merged);
    await ctx.db.patch(sceneId, patch);
    await ctx.db.patch(scene.projectId, { updatedAt: now });
    return null;
  },
});

export const replaceScenes = mutation({
  args: {
    projectId: v.id("projects"),
    scenes: v.array(v.object(sceneInputFields)),
    now: v.number(),
  },
  returns: v.null(),
  handler: async (ctx, { projectId, scenes, now }) => {
    const project = await ctx.db.get(projectId);
    if (!project) throw new Error("Không tìm thấy dự án");
    assertNum(now, "Thời gian", 0, 4102444800000);
    if (scenes.length > MAX_SCENES) throw new Error(`Tối đa ${MAX_SCENES} cảnh`);
    scenes.forEach(validateScene);
    const existing = await ctx.db
      .query("scenes")
      .withIndex("by_project", (q) => q.eq("projectId", projectId))
      .take(50);
    for (const s of existing) await ctx.db.delete(s._id);
    for (const s of scenes) await ctx.db.insert("scenes", { projectId, ...s });
    await ctx.db.patch(projectId, { updatedAt: now });
    return null;
  },
});

export const deleteProject = mutation({
  args: { projectId: v.id("projects") },
  returns: v.null(),
  handler: async (ctx, { projectId }) => {
    const project = await ctx.db.get(projectId);
    if (!project) return null;
    const existing = await ctx.db
      .query("scenes")
      .withIndex("by_project", (q) => q.eq("projectId", projectId))
      .take(50);
    for (const s of existing) await ctx.db.delete(s._id);
    await ctx.db.delete(projectId);
    return null;
  },
});
