# Director Studio — TikTok Video Pipeline (Type app)

App mini đã build & publish trên Type (ID: wart_01m4132f0pe0nakpmrbgma4a0e), dựng từ bộ skill
`tiktok-director-skill/`. Đây là 4 file nguồn do tôi viết; phần còn lại (main.tsx, typeAuth,
convex/type*.ts, package.json…) là scaffold platform-owned của Type.

## Cấu trúc
- `convex/schema.ts` — bảng `projects` (brief, hooks, character bible, timelapse 4 ô, caption, QC)
  và `scenes` (production board: SHOT/CAMERA/ACTION/SUBJECT/ENV/PROP/ANIMAL, bố cục màn hình,
  trạng thái keyframe→take→duyệt→ghép, takes, ghi chú fallback).
- `convex/app.ts` — listProjects, getProject, createProject, updateProject, updateScene,
  replaceScenes, deleteProject (validate mọi input, bounded).
- `src/App.tsx` — 8 bước: Brief → Hook → Casting → Shot list → Prompt → Lời đọc & sub → Caption → QC & bàn giao.
  Chứa toàn bộ generator: template cảnh 30/45/60s + timelapse 7 KF, keyframe/motion prompt,
  `labels.ass` / `subs.ass` (PlayRes 1080x1920), `build.sh` ffmpeg (concat, sub, beat 0.15 +
  sidechain ducking, normalize=0, alimiter 0.95), production pack .md, lint "mắt đạo diễn".
- `src/styles.css` — design tokens của Type + style riêng của app (phần cuối file).

## Ánh xạ skill → app
| Skill | Trong app |
|---|---|
| §1 Brief | Bước 1 |
| §4 Hook 6 dạng | Bước 2 (+ AI gợi ý nếu typeAi khả dụng) |
| §17.1 Character bible / production board | Bước 3 + 4 |
| §5, 7b, 7c, 7d | Template cảnh, ô SHOT/CAMERA/ACTION/cast, bố cục màn hình, lint |
| §7, 7e Prompt | Bước 5 |
| references/loi-doc-phu-de-mix.md | Bước 6 (.ass + build.sh) |
| §8 bước 8 Caption | Bước 7 |
| §9, §17.4 QC 4 lượt, §17.5 failover | Bước 8 |
| shot-list-30-keyframes.md | Format "Timelapse công trình" |
| references/capcut-workflow.md | Production pack (handoff contract) |
