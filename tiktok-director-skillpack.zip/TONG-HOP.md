# Gói kỹ năng đã xử lý — 2026-10-03

## 1. tiktok-director-skill/ (bộ skill gốc, đã đọc & tổng hợp)
- SKILL.md — skill chính v3 (brief → hook → timeline → shot list → keyframe → animate → ghép → lời đọc/sub/beat → caption → checklist).
- references/loi-doc-phu-de-mix.md — lời đọc 2,5 từ/s, .ass PlayRes 1080x1920, beat 0.15 + ducking.
- references/capcut-workflow.md — tách CapCut: hay sinh asset, AI viết kịch bản + dựng.
- references/san-xuat-dien-anh.md — tiền kỳ/quay/dựng/hậu kỳ, 2 take cảnh hero, QC 4 lượt, failover.
- references/character-swap.md — MiniMax-H3 LoRA, bắt buộc consent.
- shot-list-30-keyframes.md — timelapse công trình 30 KF, 5 luật sắt.
- README.md — mô tả bộ skill.
(2 file trùng "SKILL (1).md" và "shot-list-30-keyframes (1).md" đã bỏ.)

## 2. director-studio-app/ (sản phẩm build từ skill)
Mã nguồn app Type "Director Studio — TikTok Video Pipeline" — xem README.md bên trong.

## Pipeline rút gọn (cho đạo diễn)
1. Brief: một mục tiêu, một CTA.
2. Hook: viết 5–10 bản, chọn bản rõ nhất. Lời + hình + chữ cùng thông điệp.
3. Character bible khóa casting, paste nguyên văn vào mọi prompt.
4. Shot list: mỗi cảnh ~10s, một chuyển động camera chậm + một action; xen kẽ toàn/trung/cận;
   màn hình luôn đối diện người xem (OTS / chính diện / PiP).
5. Keyframe trước (soi logic 7d) → animate sau; 2 take cảnh hero; trích frame giữa mỗi clip.
6. Ghép 1080x1920, bỏ audio AI; sub .ass; beat 0.15 + ducking, normalize=0, alimiter 0.95.
7. Caption: hook + 2–3 câu + CTA + 5–8 hashtag.
8. QC 4 lượt (logic → chữ → tiếng → kỹ thuật). Gắn nhãn AI khi đăng.
