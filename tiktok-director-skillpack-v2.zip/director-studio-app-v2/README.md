# Director Studio v2 — đấu nối lớp tri thức (Type app wart_01m4132f0pe0nakpmrbgma4a0e)

Thay đổi so với v1 (chỉ 4 file nguồn do tôi viết; scaffold Type không kèm):

- `convex/schema.ts` — thêm bảng `briefs` (series, briefNo, source{docId, section, anchors}, claims[{text, anchors, status}],
  risk{accuracy, notes}, outline[{order, text}] = beat từng cảnh, continuity, raw). Bảng cũ giữ nguyên.
- `convex/app.ts` — thêm `getBrief`, `listBriefs`, `createProjectFromBrief`, `upsertBrief`; `deleteProject` dọn cả brief.
  Các hàm cũ giữ nguyên contract.
- `src/App.tsx`
  - `parseBrief()` — đọc brief 8 trường (v1 bullet hoặc v2 frontmatter) → ParsedBrief + warnings (audit tự động).
  - `scenesFromBrief()` — dàn ý → cảnh: HOOK 10s · ý · Tóm tắt · CTA 5s; cảnh < 8s → cảnh báo.
  - Màn **Intake**: dán/upload nhiều .md → preview → tạo cả series (bible + CTA chung).
  - Bước **2 · Claim ledger**: VERIFIED/UNVERIFIED/EDITORIAL, anchors, risk, continuity, beat; nút AI đối chiếu lời đọc.
  - Lint mới: số liệu (%, số ≥ 10) không có trong ledger; claim UNVERIFIED; cảnh < 8s; caption thiếu "mô phỏng".
  - **⚡ AI dựng nháp**: shot list → lời đọc theo beat, chỉ dùng dữ kiện trong ledger.
  - QC thêm "Lượt 5 — Claim & series"; production pack thêm Nguồn/Claim/Risk/Continuity.
- `src/styles.css` — thêm style v2 ở cuối file.
