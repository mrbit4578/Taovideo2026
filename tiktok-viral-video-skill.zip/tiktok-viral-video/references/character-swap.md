# 13. Character Swap — đổi nhân vật trong clip (MiniMax-H3 LoRA)

Dùng khi hay muốn **cùng 1 nhân vật xuất hiện xuyên suốt các clip** (tăng nhận diện kênh), hoặc đưa 1 nhân vật (cameo/thương hiệu) vào clip có sẵn.

- Backend Kiemtien2026: `POST /video/character-swap` (NestJS, Gradio API tới HF Space `hugging-apps/minimax-h3-character-swap-lora`). Spec: `docs/character-swap-minimax-h3.md`. (Chưa kết nối trên Type — cần hay cấp quyền/endpoint nếu muốn chạy từ đây.)
- Cách dùng: render từng clip ngắn **≤14s** → swap nhân vật từng clip (prompt phải nhắc `<Video 1>` và `<Picture 1>`, canvas `768x1344 · 9:16 full` cho dọc) → ghép bằng ffmpeg như pipeline thường.
- Ảnh tham chiếu: chân dung rõ mặt, nền đơn giản, ánh sáng trung tính.
- **BẮT BUỘC consent văn bản** của người thật (`consentConfirmed=true`); không consent → không làm. Mặc định REJECT, kể cả người nổi tiếng.
- Model thử nghiệm: motion timing & biểu cảm có thể lỗi — **luôn xem lại thủ công** từng clip sau swap.
- Provider free (ZeroGPU): xếp hàng, có thể timeout — không hứa thời gian; check `GET /video/character-swap/status` trước khi chạy hàng loạt.
- Mọi clip swap là AI-generated: nhắc hay **bật nhãn AI** khi đăng TikTok.
