# 15. Lời đọc + phụ đề tiếng Việt (mặc định từ 2026-09-30, theo yêu cầu của hay)

Mọi video mới đều có **lời đọc thuyết minh tiếng Việt** + **phụ đề tiếng Việt burn-in**. Thay thế default cũ "không chữ overlay / không lời thoại".
Quy trình sau bước ghép:

1. **Kịch bản lời đọc**: viết theo từng cảnh, tổng ~140–160 từ cho 60s, khớp nội dung từng keyframe, không claim y tế/tài chính chưa kiểm chứng. Viết số/thời gian bằng chữ để TTS đọc đúng.
2. **Giọng đọc**: trên Muse dùng `/opt/hatch/bin/tts speak --language vi --voice avocado_v2:briggs` (nam, ấm). Trên Type: hay sinh giọng bằng CapCut Pro (xem `capcut-workflow.md`) rồi gửi file mp3/wav. Test 1 câu trước khi làm cả bài. Giọng dự phòng: vẫn giọng nam miền Bắc.
3. **Phụ đề**: tạo `.srt` căn theo từng cảnh (mỗi cảnh ≈ 10s → 1–2 dòng sub), rồi **convert sang `.ass` với `PlayResX: 1080` / `PlayResY: 1920`** — BẮT BUỘC.
   Lý do (bài học 2026-09-30): filter `subtitles` với `.srt` dùng PlayRes mặc định 384x288 của libass → mọi giá trị px cho 1080x1920 đều sai: `MarginV=300` đẩy sub ra khỏi khung, chữ top phóng to ~6x và xuống dòng từng từ.
   Burn: `subtitles=labels.ass` rồi `subtitles=subs.ass` (2 style: Label top-center size 54, Sub bottom-center size 46, font DejaVu Sans Bold, viền đen).
   KHÔNG dùng `drawtext` cho câu tiếng Việt dài (không tự xuống dòng, dễ tràn khung).
4. **Mix tiếng**: narration giữ nguyên volume. Nhạc nền = **file beat mặc định của hay, đã lưu trên Type**: `josepmonter-mariage-damour-2186.mp3`, **fileId `file_01m4065qy6ebqvpt29s58c1s4a`** (dài ~6:32, 12.5MB, hay gửi 2026-10-03). Mỗi video: `materialize_attachment(fileId=file_01m4065qy6ebqvpt29s58c1s4a, path=/tmp/<job>/beat.mp3)` — KHÔNG hỏi lại hay, KHÔNG tự tổng hợp nhạc thay thế. Nếu tải lỗi thì thử lại 1 lần rồi mới báo hay. Cắt `atrim=0:<DUR>` khớp video, fade-out 2–3s cuối; **TẮT tiếng ambient AI của clip**.
   **Beat LUÔN nhỏ hơn lời thuyết minh** — công thức đã validate:
   ```
   [1:a]atrim=0:60,asetpts=PTS-STARTPTS,volume=0.15[beat];
   [narr]asplit=2[nkey][narr2];
   [beat][nkey]sidechaincompress=threshold=0.02:ratio=8:attack=200:release=800:makeup=1[ducked];
   [narr2][ducked]amix=inputs=2:duration=first:normalize=0,alimiter=limit=0.95[aout]
   ```
   (beat lùi ~20dB dưới narration, tự dìm thêm khi có tiếng nói).
   **BẮT BUỘC `normalize=0`** trên mọi `amix` — mặc định `normalize=1` chia nhỏ tín hiệu theo số input (5 input ≈ -14dB) khiến lời đọc lí nhí; `alimiter=limit=0.95` cuối chuỗi chống clipping. Ví dụ ghép narration nhiều đoạn:
   `[n1][n2][n3][n4][n5]amix=inputs=5:duration=longest:dropout_transition=0:normalize=0[narr]`
5. **QC**: nghe toàn bộ, kiểm tra sub không che chủ thể (sub vùng dưới, chừa lề UI TikTok).
