# 17. Sản xuất kiểu nhà sản xuất phim (kaizen 2026-10-03)

Mỗi video chạy qua 4 giai đoạn tiền kỳ / quay / dựng / hậu kỳ với cổng kiểm tra rõ ràng.

## 17.1 Tiền kỳ — quyết định 70% chất lượng

- **Character bible (khóa casting một lần)**: trước keyframe đầu tiên, viết 1 đoạn mô tả nhân vật DUY NHẤT (tuổi, tóc, trang phục từng cảnh, đặc điểm nhận dạng) và **paste nguyên văn** vào mọi prompt keyframe. Đổi 1 chữ = đổi nhân vật.
- **Production board**: shot list dạng bảng, mỗi shot có trạng thái `keyframe ☐ → take ☐ → duyệt ☐ → ghép ☐`. Không shot nào được ghép khi chưa duyệt.
- **Coverage cho cảnh chốt**: hook (0–3s) và CTA (52–60s) luôn có 2 phương án (2 góc hoặc 2 action).
- Prop/bối cảnh theo 7c; logic staging theo 7d — xong trên giấy trước khi generate.
- **Sản phẩm thật: verify hình dáng trước khi vẽ** (bài học video iPhone): KHÔNG vẽ theo trí nhớ — đối chiếu ảnh thật hay gửi hoặc image search. Sai chi tiết nhận diện (VD: cụm camera) = dựng lại toàn bộ. Hay đã gửi ảnh thật thì dùng ảnh đó làm keyframe/composite.

## 17.2 Quay — batch và dailies

- **Batch theo lớp**: sinh TẤT CẢ keyframes → verify tất cả → mới sinh TẤT CẢ clip. Không cuốn chiếu.
- **2 takes cho cảnh hero** (hook, CTA, cảnh có màn hình); cảnh thường 1 take.
- **Dailies**: frame giữa mỗi clip — kiểm tra biến dạng, logic 7d, màu sắc. Take lỗi → sinh lại.
- **Motion có kiểm soát**: mặc định motion NHẸ (camera chậm, 1 action). Motion mạnh = dễ biến dạng.

## 17.3 Dựng — chọn take và giữ liên tục

- **Pick take tốt nhất** cho mỗi cảnh rồi mới concat.
- **Continuity**: quy tắc **180°** trong cùng không gian; màu/ánh sáng đồng tone giữa các cảnh trừ khi có lý do kể chuyện.
- **Nhịp**: mỗi 3–8s có thay đổi có ý nghĩa; không 2 cảnh liên tiếp cùng cỡ shot.

## 17.4 Hậu kỳ & QC 4 lượt (theo thứ tự)

1. **Logic**: tay–mắt–vật, hướng màn hình (7d) — xem frame ranh giới các cảnh.
2. **Chữ**: sub không che chủ thể, label đúng chính tả, không tràn khung.
3. **Tiếng**: voiceover rõ, beat nhỏ hơn lời, không clipping.
4. **Kỹ thuật**: 1080x1920, đúng thời lượng (±0.5s), ≤100MB, file thật không symlink.

## 17.5 Failover khi job lỗi — thử lại → hạ cấp, không bỏ cảnh

- **Sinh video lỗi**: thử lại 1 lần với motion đơn giản hơn. Vẫn lỗi → Ken Burns từ keyframe.
- **Sinh ảnh lỗi**: thử lại 1 lần với prompt rút gọn.
- **TTS lỗi**: thử lại 1 lần → đổi voice dự phòng (giọng nam miền Bắc).
- **Batch theo đợt**: tối đa 4 job media song song — video 6 cảnh chia 2 đợt.
- **Ghi log** retry/fallback vào production board để QC soi kỹ take hạ cấp.

## Ranh giới

- Không dùng kỹ thuật xoay proxy / chuyển tài khoản / multi-profile để lách giới hạn tool bên thứ ba.
- API key quản lý qua AI Pro của Kiemtien2026 (mã hóa server-side), không lưu key local.
