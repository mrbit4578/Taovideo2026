import { v } from "convex/values";
import type { Infer } from "convex/values";
import { mutation, query } from "./typeFunctions";
import { slideFields, slideValidator } from "./validators";

type SlideInput = Infer<typeof slideValidator>;

const MAX_SLIDES = 30;

function finite(n: number, min: number, max: number, label: string) {
  if (!Number.isFinite(n) || n < min || n > max) {
    throw new Error(`${label} không hợp lệ`);
  }
}

function checkSlides(slides: SlideInput[]) {
  if (slides.length < 1 || slides.length > MAX_SLIDES) {
    throw new Error("Số cảnh phải từ 1 đến 30");
  }
  for (const s of slides) {
    if (s.key.length < 1 || s.key.length > 64) throw new Error("Khóa cảnh không hợp lệ");
    if (s.text.length > 300) throw new Error("Nội dung cảnh quá dài");
    if (s.bg.length > 32) throw new Error("Nền không hợp lệ");
    finite(s.duration, 1, 15, "Thời lượng");
    finite(s.fontSize, 32, 140, "Cỡ chữ");
  }
}

function checkText(title: string, caption: string, hashtags: string) {
  if (title.length > 120) throw new Error("Tiêu đề quá dài");
  if (caption.length > 2200) throw new Error("Caption quá dài");
  if (hashtags.length > 500) throw new Error("Hashtag quá dài");
}

export const listProjects = query({
  args: {},
  returns: v.array(
    v.object({
      _id: v.id("projects"),
      title: v.string(),
      updatedAt: v.number(),
      slideCount: v.number(),
      duration: v.number(),
    }),
  ),
  handler: async (ctx) => {
    const rows = await ctx.db
      .query("projects")
      .withIndex("by_updated")
      .order("desc")
      .take(50);
    return rows.map((p) => ({
      _id: p._id,
      title: p.title,
      updatedAt: p.updatedAt,
      slideCount: p.slides.length,
      duration: p.slides.reduce((sum, s) => sum + s.duration, 0),
    }));
  },
});

export const getProject = query({
  args: { id: v.id("projects") },
  returns: v.union(
    v.null(),
    v.object({
      _id: v.id("projects"),
      title: v.string(),
      caption: v.string(),
      hashtags: v.string(),
      updatedAt: v.number(),
      slides: v.array(
        v.object({ ...slideFields, imageUrl: v.union(v.string(), v.null()) }),
      ),
    }),
  ),
  handler: async (ctx, { id }) => {
    const p = await ctx.db.get(id);
    if (!p) return null;
    const slides = await Promise.all(
      p.slides.map(async (s) => ({
        ...s,
        imageUrl: s.imageId ? await ctx.storage.getUrl(s.imageId) : null,
      })),
    );
    return {
      _id: p._id,
      title: p.title,
      caption: p.caption,
      hashtags: p.hashtags,
      updatedAt: p.updatedAt,
      slides,
    };
  },
});

export const createProject = mutation({
  args: { title: v.string() },
  returns: v.id("projects"),
  handler: async (ctx, { title }) => {
    const clean = title.trim().slice(0, 120) || "Video mới";
    const base = {
      duration: 3,
      imageId: null,
      textPos: "center" as const,
      textColor: "white" as const,
      textStyle: "shadow" as const,
      fontSize: 76,
    };
    const stamp = Date.now().toString(36);
    return await ctx.db.insert("projects", {
      title: clean,
      caption: "",
      hashtags: "#xuhuong #fyp",
      updatedAt: Date.now(),
      slides: [
        { ...base, key: `a${stamp}`, text: "Bạn có biết điều này? 🤯", bg: "neon", animation: "pop", fontSize: 92, textStyle: "box", textColor: "black" },
        { ...base, key: `b${stamp}`, text: "Viết nội dung chính của bạn ở đây", bg: "night", animation: "slide" },
        { ...base, key: `c${stamp}`, text: "Follow để xem thêm nhé! ❤️", bg: "sunset", animation: "zoom" },
      ],
    });
  },
});

export const saveProject = mutation({
  args: {
    id: v.id("projects"),
    title: v.string(),
    caption: v.string(),
    hashtags: v.string(),
    slides: v.array(slideValidator),
  },
  returns: v.null(),
  handler: async (ctx, { id, title, caption, hashtags, slides }) => {
    const p = await ctx.db.get(id);
    if (!p) throw new Error("Không tìm thấy dự án");
    checkText(title, caption, hashtags);
    checkSlides(slides);
    await ctx.db.patch(id, { title, caption, hashtags, slides, updatedAt: Date.now() });
    return null;
  },
});

export const deleteProject = mutation({
  args: { id: v.id("projects") },
  returns: v.null(),
  handler: async (ctx, { id }) => {
    const p = await ctx.db.get(id);
    if (!p) return null;
    for (const s of p.slides) {
      if (s.imageId) {
        try {
          await ctx.storage.delete(s.imageId);
        } catch {
          // already removed
        }
      }
    }
    await ctx.db.delete(id);
    return null;
  },
});

export const generateUploadUrl = mutation({
  args: {},
  returns: v.string(),
  handler: async (ctx) => {
    return await ctx.storage.generateUploadUrl();
  },
});
