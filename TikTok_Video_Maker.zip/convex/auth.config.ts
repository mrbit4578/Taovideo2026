// Platform-owned by Type. Lets this app's Convex backend verify
// Type-authorized viewers through ctx.auth.getUserIdentity(). Do not edit or delete.
export default {
  providers: [
    {
      type: "customJwt",
      issuer: "https://api.type.com/api/type-app-auth",
      jwks: "https://api.type.com/api/type-app-auth/jwks.json",
      algorithm: "RS256",
      applicationID: "type-app:v2:31:wart_01m412x3qhe5ya13ftnwsmcj62:35:dev/wapb-01m412x3qhe5ya13fzr5p6vam0",
    },
  ],
};
