import { defineSchema, defineTable } from "convex/server";
import { v } from "convex/values";
import { typePlatformTables } from "./typeSchema";
import { slideValidator } from "./validators";

export default defineSchema({
  ...typePlatformTables,
  projects: defineTable({
    title: v.string(),
    caption: v.string(),
    hashtags: v.string(),
    slides: v.array(slideValidator),
    updatedAt: v.number(),
  }).index("by_updated", ["updatedAt"]),
});
