import { useCallback, useEffect, useRef, useState } from "react";
import { useMutation, useQuery } from "convex/react";
import { api } from "../convex/_generated/api";
import type { Id } from "../convex/_generated/dataModel";
import { useTypeAppSession } from "./typeAuth";
import {
  BACKGROUNDS,
  H,
  TEXT_COLORS,
  W,
  bgById,
  drawFrame,
  locate,
  slideStart,
  totalDuration,
  type Anim,
  type Slide,
  type TextColor,
  type TextPos,
  type TextStyle,
} from "./render";

type Draft = { title: string; caption: string; hashtags: string; slides: Slide[] };

const ANIMS: Array<{ id: Anim; label: string }> = [
  { id: "fade", label: "Mờ dần" },
  { id: "zoom", label: "Phóng to" },
  { id: "slide", label: "Trượt lên" },
  { id: "pop", label: "Bật nảy" },
  { id: "type", label: "Đánh máy" },
];
const POSITIONS: Array<{ id: TextPos; label: string }> = [
  { id: "top", label: "Trên" },
  { id: "center", label: "Giữa" },
  { id: "bottom", label: "Dưới" },
];
const COLORS: Array<{ id: TextColor; label: string }> = [
  { id: "white", label: "Trắng" },
  { id: "black", label: "Đen" },
  { id: "yellow", label: "Vàng" },
];
const STYLES: Array<{ id: TextStyle; label: string }> = [
  { id: "shadow", label: "Đổ bóng" },
  { id: "box", label: "Nền chữ" },
];
const TONES = ["truyền cảm hứng", "hài hước", "giáo dục / mẹo hay", "bán hàng", "kể chuyện"];
const MIME_CANDIDATES = [
  "video/mp4;codecs=avc1.42E01E,mp4a.40.2",
  "video/mp4;codecs=avc1",
  "video/mp4",
  "video/webm;codecs=vp9,opus",
  "video/webm;codecs=vp8,opus",
  "video/webm",
];

function newKey() {
  return Math.random().toString(36).slice(2, 10) + Date.now().toString(36);
}

function makeSlide(partial?: Partial<Slide>): Slide {
  return {
    key: newKey(),
    text: "Nội dung mới",
    duration: 3,
    bg: "night",
    imageId: null,
    animation: "fade",
    textPos: "center",
    textColor: "white",
    textStyle: "shadow",
    fontSize: 76,
    ...partial,
  };
}

function fmt(s: number) {
  const m = Math.floor(s / 60);
  const r = Math.floor(s % 60);
  return `${m}:${r.toString().padStart(2, "0")}`;
}

function clamp(n: number, a: number, b: number) {
  return Math.min(b, Math.max(a, n));
}

/* ---------------- App shell ---------------- */

export function App() {
  const session = useTypeAppSession();
  const canWrite = session.capabilities.write;
  const projects = useQuery(api.app.listProjects);
  const createProject = useMutation(api.app.createProject);
  const [selectedId, setSelectedId] = useState<Id<"projects"> | null>(null);
  const [creating, setCreating] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!projects) return;
    if (selectedId === null || !projects.some((p) => p._id === selectedId)) {
      setSelectedId(projects[0]?._id ?? null);
    }
  }, [projects, selectedId]);

  const onCreate = async () => {
    setCreating(true);
    setError(null);
    try {
      const id = await createProject({ title: "Video mới" });
      setSelectedId(id);
    } catch {
      setError("Không tạo được dự án. Hãy thử lại.");
    } finally {
      setCreating(false);
    }
  };

  return (
    <main className="app-shell tvm">
      <header className="tvm-header">
        <div>
          <h1>TikTok Video Maker</h1>
          <p className="text-secondary">
            Tạo video dọc 9:16 từ chữ, ảnh và nhạc — xuất file để đăng TikTok.
          </p>
        </div>
        {!canWrite && <span className="badge">Chế độ chỉ xem</span>}
      </header>

      <div className="tvm-layout">
        <aside className="card tvm-sidebar">
          <div className="tvm-between">
            <span className="text-label">Dự án</span>
            <button
              className="button button-primary tvm-small"
              disabled={!canWrite || creating}
              onClick={onCreate}
            >
              {creating ? "Đang tạo…" : "+ Video mới"}
            </button>
          </div>
          {error && <p className="tvm-error">{error}</p>}
          {projects === undefined ? (
            <p className="text-secondary tvm-tiny">Đang tải…</p>
          ) : projects.length === 0 ? (
            <p className="text-secondary tvm-tiny">Chưa có video nào.</p>
          ) : (
            <ul className="tvm-project-list">
              {projects.map((p) => (
                <li key={p._id}>
                  <button
                    className={`tvm-project ${p._id === selectedId ? "is-active" : ""}`}
                    onClick={() => setSelectedId(p._id)}
                  >
                    <span className="tvm-project-title">{p.title || "Không tên"}</span>
                    <span className="text-secondary tvm-tiny">
                      {p.slideCount} cảnh · {fmt(p.duration)}
                    </span>
                  </button>
                </li>
              ))}
            </ul>
          )}
        </aside>

        <section className="tvm-main">
          {selectedId ? (
            <Editor key={selectedId} projectId={selectedId} canWrite={canWrite} />
          ) : (
            <div className="card tvm-empty-big">
              <div className="tvm-empty-phone" aria-hidden>
                <span>9:16</span>
              </div>
              <h2>Bắt đầu video TikTok đầu tiên</h2>
              <p className="text-secondary">
                Viết từng cảnh hoặc để AI gợi ý kịch bản, thêm ảnh &amp; nhạc, rồi xuất video
                để đăng.
              </p>
              <button
                className="button button-primary"
                disabled={!canWrite || creating}
                onClick={onCreate}
              >
                + Tạo video mới
              </button>
            </div>
          )}
        </section>
      </div>
    </main>
  );
}

/* ---------------- Images ---------------- */

function useImages(urls: Record<string, string>) {
  const cache = useRef(new Map<string, HTMLImageElement>());
  const [version, setVersion] = useState(0);
  useEffect(() => {
    for (const [id, url] of Object.entries(urls)) {
      if (cache.current.has(id)) continue;
      const img = new Image();
      img.crossOrigin = "anonymous";
      img.onload = () => setVersion((v) => v + 1);
      img.src = url;
      cache.current.set(id, img);
    }
  }, [urls]);
  return { images: cache.current, version };
}

/* ---------------- Editor ---------------- */

function Editor({ projectId, canWrite }: { projectId: Id<"projects">; canWrite: boolean }) {
  const project = useQuery(api.app.getProject, { id: projectId });
  const save = useMutation(api.app.saveProject);
  const remove = useMutation(api.app.deleteProject);
  const genUpload = useMutation(api.app.generateUploadUrl);

  const [draft, setDraft] = useState<Draft | null>(null);
  const [urls, setUrls] = useState<Record<string, string>>({});
  const [sel, setSel] = useState(0);
  const [saveState, setSaveState] = useState<"idle" | "saving" | "saved" | "error">("idle");
  const [music, setMusic] = useState<{ file: File; url: string } | null>(null);
  const [uploading, setUploading] = useState(false);
  const [uploadError, setUploadError] = useState<string | null>(null);
  const [confirmDelete, setConfirmDelete] = useState(false);
  const [undo, setUndo] = useState<Draft | null>(null);
  const lastSaved = useRef("");
  const pending = useRef<Draft | null>(null);
  const { images, version } = useImages(urls);

  useEffect(() => {
    if (!project || draft) return;
    const d: Draft = {
      title: project.title,
      caption: project.caption,
      hashtags: project.hashtags,
      slides: project.slides.map((s) => ({
        key: s.key,
        text: s.text,
        duration: s.duration,
        bg: s.bg,
        imageId: s.imageId,
        animation: s.animation,
        textPos: s.textPos,
        textColor: s.textColor,
        textStyle: s.textStyle,
        fontSize: s.fontSize,
      })),
    };
    const u: Record<string, string> = {};
    for (const s of project.slides) if (s.imageId && s.imageUrl) u[s.imageId] = s.imageUrl;
    setUrls((prev) => ({ ...u, ...prev }));
    lastSaved.current = JSON.stringify(d);
    setDraft(d);
  }, [project, draft]);

  const doSave = useCallback(
    async (d: Draft) => {
      const json = JSON.stringify(d);
      if (json === lastSaved.current) return;
      setSaveState("saving");
      try {
        await save({
          id: projectId,
          title: d.title,
          caption: d.caption,
          hashtags: d.hashtags,
          slides: d.slides.map((s) => ({ ...s, imageId: s.imageId as Id<"_storage"> | null })),
        });
        lastSaved.current = json;
        if (pending.current === d) pending.current = null;
        setSaveState("saved");
      } catch {
        setSaveState("error");
      }
    },
    [projectId, save],
  );

  useEffect(() => {
    if (!draft || !canWrite) return;
    if (JSON.stringify(draft) === lastSaved.current) return;
    pending.current = draft;
    const t = window.setTimeout(() => void doSave(draft), 700);
    return () => window.clearTimeout(t);
  }, [draft, canWrite, doSave]);

  useEffect(
    () => () => {
      if (pending.current) void doSave(pending.current);
    },
    [doSave],
  );

  useEffect(() => () => {
    if (music) URL.revokeObjectURL(music.url);
  }, [music]);

  if (project === undefined || (project && !draft)) {
    return <div className="card tvm-loading">Đang mở video…</div>;
  }
  if (project === null || !draft) {
    return <div className="card tvm-loading">Không tìm thấy video này.</div>;
  }

  const slides = draft.slides;
  const index = clamp(sel, 0, slides.length - 1);
  const current = slides[index];

  const update = (patch: Partial<Draft>) => setDraft((d) => (d ? { ...d, ...patch } : d));
  const updateSlide = (i: number, patch: Partial<Slide>) =>
    setDraft((d) =>
      d ? { ...d, slides: d.slides.map((s, j) => (j === i ? { ...s, ...patch } : s)) } : d,
    );
  const setSlides = (next: Slide[]) => update({ slides: next });

  const addSlide = () => {
    if (slides.length >= 30) return;
    const s = makeSlide({
      bg: current.bg,
      animation: current.animation,
      textColor: current.textColor,
      textStyle: current.textStyle,
      textPos: current.textPos,
      fontSize: current.fontSize,
    });
    const next = [...slides.slice(0, index + 1), s, ...slides.slice(index + 1)];
    setSlides(next);
    setSel(index + 1);
  };
  const duplicate = (i: number) => {
    if (slides.length >= 30) return;
    const next = [...slides];
    next.splice(i + 1, 0, { ...slides[i], key: newKey() });
    setSlides(next);
    setSel(i + 1);
  };
  const removeSlide = (i: number) => {
    if (slides.length <= 1) return;
    setSlides(slides.filter((_, j) => j !== i));
    setSel(Math.max(0, i - 1));
  };
  const move = (i: number, dir: -1 | 1) => {
    const j = i + dir;
    if (j < 0 || j >= slides.length) return;
    const next = [...slides];
    [next[i], next[j]] = [next[j], next[i]];
    setSlides(next);
    setSel(j);
  };
  const applyStyleToAll = () => {
    setSlides(
      slides.map((s) => ({
        ...s,
        bg: current.bg,
        animation: current.animation,
        textColor: current.textColor,
        textStyle: current.textStyle,
        textPos: current.textPos,
      })),
    );
  };

  const onPickImage = async (i: number, file: File) => {
    setUploadError(null);
    if (!file.type.startsWith("image/")) {
      setUploadError("Hãy chọn một tệp ảnh.");
      return;
    }
    if (file.size > 8 * 1024 * 1024) {
      setUploadError("Ảnh tối đa 8 MB.");
      return;
    }
    setUploading(true);
    try {
      const uploadUrl = await genUpload();
      const res = await fetch(uploadUrl, {
        method: "POST",
        headers: { "Content-Type": file.type },
        body: file,
      });
      if (!res.ok) throw new Error("upload");
      const { storageId } = (await res.json()) as { storageId: string };
      const local = URL.createObjectURL(file);
      setUrls((u) => ({ ...u, [storageId]: local }));
      updateSlide(i, { imageId: storageId });
    } catch {
      setUploadError("Tải ảnh lên thất bại. Hãy thử lại.");
    } finally {
      setUploading(false);
    }
  };

  const onAiResult = (r: { title: string; texts: string[]; caption: string; hashtags: string }) => {
    setUndo(draft);
    const palette = ["neon", "night", "sunset", "ocean", "candy", "mint", "aqua", "dark"];
    const anims: Anim[] = ["slide", "fade", "zoom", "type"];
    const last = r.texts.length - 1;
    const next = r.texts.slice(0, 30).map((text, i) => {
      const words = text.split(/\s+/).filter(Boolean).length;
      return makeSlide({
        text: text.slice(0, 300),
        duration: Math.round(clamp(1.5 + words * 0.32, 2.5, 6) * 2) / 2,
        bg: palette[i % palette.length],
        animation: i === 0 ? "pop" : i === last ? "zoom" : anims[(i - 1) % anims.length],
        fontSize: i === 0 ? 92 : text.length > 70 ? 58 : text.length > 40 ? 66 : 76,
        textStyle: i === 0 ? "box" : "shadow",
        textColor: i === 0 ? "black" : "white",
      });
    });
    setDraft({
      title: r.title.slice(0, 120) || draft.title,
      caption: r.caption.slice(0, 2200),
      hashtags: r.hashtags.slice(0, 500),
      slides: next.length ? next : draft.slides,
    });
    setSel(0);
  };

  const onDelete = async () => {
    if (!confirmDelete) {
      setConfirmDelete(true);
      return;
    }
    pending.current = null;
    lastSaved.current = JSON.stringify(draft);
    try {
      await remove({ id: projectId });
    } catch {
      setConfirmDelete(false);
    }
  };

  const total = totalDuration(slides);
  const saveLabel = !canWrite
    ? "Chỉ xem"
    : saveState === "saving"
      ? "Đang lưu…"
      : saveState === "error"
        ? "Lưu thất bại"
        : saveState === "saved"
          ? "Đã lưu"
          : "Tự động lưu";

  return (
    <div className="tvm-editor-wrap">
      <div className="card tvm-toolbar">
        <input
          className="input tvm-title-input"
          value={draft.title}
          maxLength={120}
          disabled={!canWrite}
          onChange={(e) => update({ title: e.target.value })}
          aria-label="Tên video"
        />
        <span className="badge">{slides.length} cảnh · {fmt(total)}</span>
        <span className={`badge ${saveState === "error" ? "badge-error" : saveState === "saved" ? "badge-success" : ""}`}>
          {saveLabel}
        </span>
        <div className="tvm-spacer" />
        {undo && (
          <button
            className="button tvm-small"
            onClick={() => {
              setDraft(undo);
              setUndo(null);
              setSel(0);
            }}
          >
            ↶ Hoàn tác AI
          </button>
        )}
        <button
          className={`button tvm-small ${confirmDelete ? "tvm-danger" : ""}`}
          disabled={!canWrite}
          onClick={onDelete}
          onBlur={() => setConfirmDelete(false)}
        >
          {confirmDelete ? "Bấm lần nữa để xóa" : "Xóa video"}
        </button>
      </div>

      <div className="tvm-editor">
        {/* Scene list */}
        <div className="tvm-col">
          <div className="card tvm-panel">
            <div className="tvm-between">
              <span className="text-label">Các cảnh</span>
              <button
                className="button tvm-small"
                disabled={!canWrite || slides.length >= 30}
                onClick={addSlide}
              >
                + Thêm cảnh
              </button>
            </div>
            <ol className="tvm-slide-list">
              {slides.map((s, i) => {
                const [a, b] = bgById(s.bg).colors;
                return (
                  <li key={s.key}>
                    <div
                      className={`tvm-slide-item ${i === index ? "is-active" : ""}`}
                      onClick={() => setSel(i)}
                      role="button"
                      tabIndex={0}
                      onKeyDown={(e) => {
                        if (e.key === "Enter") setSel(i);
                      }}
                    >
                      <span
                        className="tvm-thumb"
                        style={{
                          background:
                            s.imageId && urls[s.imageId]
                              ? `center/cover url(${JSON.stringify(urls[s.imageId])})`
                              : `linear-gradient(135deg, ${a}, ${b})`,
                        }}
                      >
                        {i + 1}
                      </span>
                      <span className="tvm-slide-text">
                        <span className="tvm-clamp">{s.text || "(trống)"}</span>
                        <span className="text-secondary tvm-tiny">{s.duration}s</span>
                      </span>
                      {i === index && canWrite && (
                        <span className="tvm-slide-actions" onClick={(e) => e.stopPropagation()}>
                          <button className="tvm-icon" title="Lên" onClick={() => move(i, -1)} disabled={i === 0}>↑</button>
                          <button className="tvm-icon" title="Xuống" onClick={() => move(i, 1)} disabled={i === slides.length - 1}>↓</button>
                          <button className="tvm-icon" title="Nhân bản" onClick={() => duplicate(i)} disabled={slides.length >= 30}>⧉</button>
                          <button className="tvm-icon" title="Xóa" onClick={() => removeSlide(i)} disabled={slides.length <= 1}>✕</button>
                        </span>
                      )}
                    </div>
                  </li>
                );
              })}
            </ol>
          </div>
          <AiPanel disabled={!canWrite} onResult={onAiResult} />
        </div>

        {/* Preview */}
        <div className="tvm-col tvm-center">
          <Preview
            slides={slides}
            images={images}
            imgVersion={version}
            selected={index}
            music={music}
            fileName={draft.title}
          />
        </div>

        {/* Inspector */}
        <div className="tvm-col">
          <fieldset className="card tvm-panel tvm-fieldset" disabled={!canWrite}>
            <span className="text-label">Cảnh {index + 1}</span>
            <label className="tvm-field">
              <span className="tvm-field-label">Nội dung chữ</span>
              <textarea
                className="input tvm-textarea"
                value={current.text}
                maxLength={300}
                rows={4}
                onChange={(e) => updateSlide(index, { text: e.target.value })}
                placeholder="Nhập chữ hiển thị trên video…"
              />
            </label>
            <label className="tvm-field">
              <span className="tvm-field-label">
                Thời lượng <b>{current.duration}s</b>
              </span>
              <input
                type="range"
                min={1}
                max={10}
                step={0.5}
                value={current.duration}
                onChange={(e) => updateSlide(index, { duration: Number(e.target.value) })}
              />
            </label>
            <label className="tvm-field">
              <span className="tvm-field-label">
                Cỡ chữ <b>{current.fontSize}</b>
              </span>
              <input
                type="range"
                min={40}
                max={130}
                step={2}
                value={current.fontSize}
                onChange={(e) => updateSlide(index, { fontSize: Number(e.target.value) })}
              />
            </label>
            <Segmented label="Vị trí chữ" options={POSITIONS} value={current.textPos} onChange={(v) => updateSlide(index, { textPos: v })} />
            <div className="tvm-field">
              <span className="tvm-field-label">Màu chữ</span>
              <div className="tvm-seg">
                {COLORS.map((c) => (
                  <button
                    key={c.id}
                    type="button"
                    className={current.textColor === c.id ? "is-active" : ""}
                    onClick={() => updateSlide(index, { textColor: c.id })}
                  >
                    <span className="tvm-dot" style={{ background: TEXT_COLORS[c.id] }} />
                    {c.label}
                  </button>
                ))}
              </div>
            </div>
            <Segmented label="Kiểu chữ" options={STYLES} value={current.textStyle} onChange={(v) => updateSlide(index, { textStyle: v })} />
            <Segmented label="Hiệu ứng" options={ANIMS} value={current.animation} onChange={(v) => updateSlide(index, { animation: v })} />
            <div className="tvm-field">
              <span className="tvm-field-label">Nền màu</span>
              <div className="tvm-swatches">
                {BACKGROUNDS.map((b) => (
                  <button
                    key={b.id}
                    type="button"
                    title={b.name}
                    aria-label={b.name}
                    className={`tvm-swatch ${current.bg === b.id ? "is-active" : ""}`}
                    style={{ background: `linear-gradient(135deg, ${b.colors[0]}, ${b.colors[1]})` }}
                    onClick={() => updateSlide(index, { bg: b.id })}
                  />
                ))}
              </div>
            </div>
            <div className="tvm-field">
              <span className="tvm-field-label">Ảnh nền (tùy chọn)</span>
              <div className="tvm-row-wrap">
                <label className={`button tvm-small ${uploading || !canWrite ? "is-disabled" : ""}`}>
                  {uploading ? "Đang tải lên…" : current.imageId ? "Đổi ảnh" : "Chọn ảnh"}
                  <input
                    type="file"
                    accept="image/*"
                    hidden
                    disabled={uploading || !canWrite}
                    onChange={(e) => {
                      const f = e.target.files?.[0];
                      e.target.value = "";
                      if (f) void onPickImage(index, f);
                    }}
                  />
                </label>
                {current.imageId && (
                  <button type="button" className="button tvm-small" onClick={() => updateSlide(index, { imageId: null })}>
                    Bỏ ảnh
                  </button>
                )}
              </div>
              {uploadError && <p className="tvm-error">{uploadError}</p>}
            </div>
            <button type="button" className="button tvm-small" onClick={applyStyleToAll}>
              Áp dụng kiểu này cho mọi cảnh
            </button>
          </fieldset>

          <div className="card tvm-panel">
            <span className="text-label">Nhạc nền</span>
            <p className="text-secondary tvm-tiny">
              Chọn tệp nhạc trên máy (MP3, M4A…). Nhạc chỉ dùng khi xem thử và xuất video, không
              được lưu lên app. Bạn cũng có thể thêm nhạc thịnh hành ngay trong TikTok khi đăng.
            </p>
            <div className="tvm-row-wrap">
              <label className="button tvm-small">
                {music ? "Đổi nhạc" : "Chọn nhạc"}
                <input
                  type="file"
                  accept="audio/*"
                  hidden
                  onChange={(e) => {
                    const f = e.target.files?.[0];
                    e.target.value = "";
                    if (f) setMusic({ file: f, url: URL.createObjectURL(f) });
                  }}
                />
              </label>
              {music && (
                <>
                  <span className="tvm-tiny tvm-clamp1">🎵 {music.file.name}</span>
                  <button className="button tvm-small" onClick={() => setMusic(null)}>Bỏ</button>
                </>
              )}
            </div>
          </div>

          <CaptionPanel
            caption={draft.caption}
            hashtags={draft.hashtags}
            disabled={!canWrite}
            onChange={(patch) => update(patch)}
          />
        </div>
      </div>
    </div>
  );
}

function Segmented<T extends string>({
  label,
  options,
  value,
  onChange,
}: {
  label: string;
  options: Array<{ id: T; label: string }>;
  value: T;
  onChange: (v: T) => void;
}) {
  return (
    <div className="tvm-field">
      <span className="tvm-field-label">{label}</span>
      <div className="tvm-seg">
        {options.map((o) => (
          <button
            key={o.id}
            type="button"
            className={value === o.id ? "is-active" : ""}
            onClick={() => onChange(o.id)}
          >
            {o.label}
          </button>
        ))}
      </div>
    </div>
  );
}

/* ---------------- Preview & export ---------------- */

function Preview({
  slides,
  images,
  imgVersion,
  selected,
  music,
  fileName,
}: {
  slides: Slide[];
  images: Map<string, HTMLImageElement>;
  imgVersion: number;
  selected: number;
  music: { file: File; url: string } | null;
  fileName: string;
}) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const audioRef = useRef<HTMLAudioElement>(null);
  const slidesRef = useRef(slides);
  slidesRef.current = slides;
  const [playing, setPlaying] = useState(false);
  const [time, setTime] = useState<number | null>(null);
  const [exporting, setExporting] = useState(false);
  const [progress, setProgress] = useState(0);
  const [result, setResult] = useState<{ url: string; ext: string; size: number } | null>(null);
  const [exportError, setExportError] = useState<string | null>(null);
  const total = totalDuration(slides);

  const draw = useCallback(
    (t: number) => {
      const ctx = canvasRef.current?.getContext("2d");
      if (ctx) drawFrame(ctx, slidesRef.current, images, t);
    },
    [images],
  );

  const sel = clamp(selected, 0, Math.max(0, slides.length - 1));
  const restT = slides.length
    ? slideStart(slides, sel) + Math.max(0, Math.min(slides[sel].duration - 0.05, 1.4))
    : 0;

  useEffect(() => {
    setTime(null);
  }, [selected]);

  useEffect(() => {
    if (playing || exporting) return;
    draw(time ?? restT);
  }, [playing, exporting, time, restT, draw, slides, imgVersion]);

  useEffect(() => {
    if (!playing) return;
    let raf = 0;
    const startAt = time !== null && time < total - 0.05 ? time : 0;
    const t0 = performance.now() - startAt * 1000;
    const audio = audioRef.current;
    if (audio) {
      audio.currentTime = startAt;
      void audio.play().catch(() => undefined);
    }
    const tick = () => {
      const t = (performance.now() - t0) / 1000;
      if (t >= total) {
        setTime(null);
        setPlaying(false);
        return;
      }
      draw(t);
      setTime(t);
      raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => {
      cancelAnimationFrame(raf);
      audio?.pause();
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [playing]);

  useEffect(() => () => {
    if (result) URL.revokeObjectURL(result.url);
  }, [result]);

  const onExport = async () => {
    const canvas = canvasRef.current;
    if (!canvas || slides.length === 0) return;
    if (typeof MediaRecorder === "undefined" || typeof canvas.captureStream !== "function") {
      setExportError("Trình duyệt này không hỗ trợ xuất video. Hãy dùng Chrome, Edge hoặc Firefox bản mới.");
      return;
    }
    const mime = MIME_CANDIDATES.find((m) => MediaRecorder.isTypeSupported(m)) ?? "";
    setPlaying(false);
    setExporting(true);
    setExportError(null);
    setProgress(0);
    setResult(null);
    let audioCtx: AudioContext | null = null;
    try {
      const stream = canvas.captureStream(30);
      let source: AudioBufferSourceNode | null = null;
      let gain: GainNode | null = null;
      if (music) {
        audioCtx = new AudioContext();
        const buf = await audioCtx.decodeAudioData(await music.file.arrayBuffer());
        source = audioCtx.createBufferSource();
        source.buffer = buf;
        gain = audioCtx.createGain();
        const dest = audioCtx.createMediaStreamDestination();
        source.connect(gain);
        gain.connect(dest);
        gain.connect(audioCtx.destination);
        dest.stream.getAudioTracks().forEach((t) => stream.addTrack(t));
      }
      const opts: MediaRecorderOptions = { videoBitsPerSecond: 8_000_000 };
      if (mime) opts.mimeType = mime;
      const recorder = new MediaRecorder(stream, opts);
      const chunks: Blob[] = [];
      recorder.ondataavailable = (e) => {
        if (e.data.size > 0) chunks.push(e.data);
      };
      const stopped = new Promise<void>((resolve) => {
        recorder.onstop = () => resolve();
      });
      draw(0);
      recorder.start(250);
      if (source && gain && audioCtx) {
        const now = audioCtx.currentTime;
        gain.gain.setValueAtTime(1, now + Math.max(0, total - 1.2));
        gain.gain.linearRampToValueAtTime(0, now + total);
        source.start();
      }
      const t0 = performance.now();
      await new Promise<void>((resolve) => {
        const tick = () => {
          const t = (performance.now() - t0) / 1000;
          if (t >= total) {
            draw(total - 0.001);
            resolve();
            return;
          }
          draw(t);
          setProgress(t / total);
          requestAnimationFrame(tick);
        };
        requestAnimationFrame(tick);
      });
      await new Promise((r) => setTimeout(r, 250));
      recorder.stop();
      source?.stop();
      await stopped;
      stream.getTracks().forEach((t) => t.stop());
      const type = recorder.mimeType || mime || "video/webm";
      const blob = new Blob(chunks, { type });
      if (blob.size === 0) throw new Error("empty");
      setResult({ url: URL.createObjectURL(blob), ext: type.includes("mp4") ? "mp4" : "webm", size: blob.size });
    } catch {
      setExportError("Xuất video thất bại. Hãy giữ tab này mở và thử lại.");
    } finally {
      if (audioCtx) void audioCtx.close();
      setExporting(false);
      setProgress(0);
    }
  };

  const shownT = exporting ? progress * total : time ?? restT;
  const curIndex = slides.length ? locate(slides, shownT).index : 0;
  const safeName = (fileName || "tiktok-video").replace(/[\\/:*?"<>|]+/g, "").trim() || "tiktok-video";

  return (
    <div className="tvm-preview">
      <div className="tvm-phone">
        <canvas ref={canvasRef} width={W} height={H} className="tvm-canvas" />
        <div className="tvm-overlay" aria-hidden>
          <div className="tvm-overlay-side">
            <span>♥</span>
            <span>💬</span>
            <span>↗</span>
          </div>
        </div>
        {exporting && (
          <div className="tvm-exporting">
            <span>Đang xuất video… {Math.round(progress * 100)}%</span>
          </div>
        )}
      </div>
      {music && <audio ref={audioRef} src={music.url} preload="auto" />}

      <div className="card tvm-controls">
        <div className="tvm-row-wrap">
          <button
            className="button tvm-play"
            disabled={exporting || slides.length === 0}
            onClick={() => setPlaying((p) => !p)}
          >
            {playing ? "❚❚ Dừng" : "▶ Xem thử"}
          </button>
          <span className="tvm-tiny text-secondary">
            Cảnh {curIndex + 1}/{slides.length} · {fmt(shownT)} / {fmt(total)}
          </span>
        </div>
        <input
          type="range"
          className="tvm-scrub"
          min={0}
          max={Math.max(0.1, total)}
          step={0.05}
          value={Math.min(shownT, total)}
          disabled={exporting}
          onChange={(e) => {
            setPlaying(false);
            setTime(Number(e.target.value));
          }}
          aria-label="Tua video"
        />
        {exporting && (
          <div className="tvm-progress">
            <div style={{ width: `${Math.round(progress * 100)}%` }} />
          </div>
        )}
        <button
          className="button button-primary tvm-export"
          disabled={exporting || slides.length === 0}
          onClick={onExport}
        >
          {exporting ? "Đang xuất…" : "⬇ Xuất video 720×1280"}
        </button>
        <p className="tvm-tiny text-secondary">
          Video được ghi theo thời gian thực (~{fmt(total)}). Giữ tab này mở trong lúc xuất.
        </p>
        {exportError && <p className="tvm-error">{exportError}</p>}
        {result && (
          <div className="tvm-result">
            <video src={result.url} controls playsInline className="tvm-result-video" />
            <div className="tvm-result-info">
              <span className="badge badge-success">Xong · {(result.size / 1024 / 1024).toFixed(1)} MB · .{result.ext}</span>
              <a className="button button-primary tvm-small" href={result.url} download={`${safeName}.${result.ext}`}>
                Tải video về
              </a>
              <span className="tvm-tiny text-secondary">
                Mở TikTok → “+” → Tải lên, chọn file vừa tải và dán caption bên dưới.
              </span>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

/* ---------------- Caption ---------------- */

function CaptionPanel({
  caption,
  hashtags,
  disabled,
  onChange,
}: {
  caption: string;
  hashtags: string;
  disabled: boolean;
  onChange: (patch: { caption?: string; hashtags?: string }) => void;
}) {
  const [copied, setCopied] = useState<"idle" | "ok" | "fail">("idle");
  const full = [caption.trim(), hashtags.trim()].filter(Boolean).join("\n\n");
  const copy = async () => {
    try {
      await navigator.clipboard.writeText(full);
      setCopied("ok");
    } catch {
      setCopied("fail");
    }
    window.setTimeout(() => setCopied("idle"), 2000);
  };
  return (
    <fieldset className="card tvm-panel tvm-fieldset" disabled={disabled}>
      <span className="text-label">Caption đăng TikTok</span>
      <textarea
        className="input tvm-textarea"
        rows={3}
        maxLength={2200}
        value={caption}
        placeholder="Viết mô tả cho video…"
        onChange={(e) => onChange({ caption: e.target.value })}
      />
      <input
        className="input"
        value={hashtags}
        maxLength={500}
        placeholder="#xuhuong #fyp"
        onChange={(e) => onChange({ hashtags: e.target.value })}
      />
      <div className="tvm-row-wrap">
        <button type="button" className="button tvm-small" disabled={!full} onClick={copy}>
          {copied === "ok" ? "Đã sao chép ✓" : "Sao chép caption"}
        </button>
        <span className="tvm-tiny text-secondary">{full.length}/2200</span>
      </div>
      {copied === "fail" && (
        <p className="tvm-tiny text-secondary">Không sao chép tự động được — hãy bôi đen và sao chép thủ công.</p>
      )}
    </fieldset>
  );
}

/* ---------------- AI ---------------- */

function AiPanel({
  disabled,
  onResult,
}: {
  disabled: boolean;
  onResult: (r: { title: string; texts: string[]; caption: string; hashtags: string }) => void;
}) {
  const [topic, setTopic] = useState("");
  const [tone, setTone] = useState(TONES[0]);
  const [count, setCount] = useState(6);
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState<string | null>(null);
  const ai = window.typeAi;

  if (!ai?.available) {
    return (
      <div className="card tvm-panel">
        <span className="text-label">✨ Kịch bản bằng AI</span>
        <p className="text-secondary tvm-tiny">
          Trợ lý AI chưa khả dụng ở đây. Bạn vẫn có thể tự viết nội dung cho từng cảnh.
        </p>
      </div>
    );
  }

  const run = async () => {
    const t = topic.trim();
    if (!t) {
      setErr("Hãy nhập chủ đề video.");
      return;
    }
    setBusy(true);
    setErr(null);
    try {
      const res = await ai.complete(
        `Viết kịch bản cho một video TikTok dạng chữ trên màn hình về chủ đề: "${t.slice(0, 300)}".
Giọng điệu: ${tone}. Số cảnh: đúng ${count}.
Quy tắc:
- Cảnh 1 là câu hook gây tò mò mạnh, tối đa 10 từ.
- Mỗi cảnh tối đa 22 từ, đọc được trong 3 giây, có thể có 1 emoji phù hợp.
- Nội dung cụ thể, có giá trị, không chung chung.
- Cảnh cuối là lời kêu gọi hành động (follow / bình luận / lưu lại).
Kèm tiêu đề ngắn cho dự án, caption hấp dẫn 1–2 câu và 5–8 hashtag liên quan (bắt đầu bằng #, không dấu cách).`,
        {
          system:
            "Bạn là biên kịch video TikTok ngắn, viral. Trả lời bằng tiếng Việt trừ khi chủ đề yêu cầu ngôn ngữ khác.",
          maxOutputTokens: 1024,
          schema: {
            type: "object",
            properties: {
              title: { type: "string" },
              slides: { type: "array", items: { type: "string" } },
              caption: { type: "string" },
              hashtags: { type: "array", items: { type: "string" } },
            },
            required: ["title", "slides", "caption", "hashtags"],
          },
        },
      );
      const texts = Array.isArray(res.slides)
        ? res.slides.filter((s): s is string => typeof s === "string" && s.trim().length > 0).map((s) => s.trim())
        : [];
      if (texts.length === 0) throw new Error("empty");
      const tags = Array.isArray(res.hashtags)
        ? res.hashtags
            .filter((h): h is string => typeof h === "string")
            .map((h) => h.trim().replace(/\s+/g, ""))
            .filter(Boolean)
            .map((h) => (h.startsWith("#") ? h : `#${h}`))
            .join(" ")
        : "";
      onResult({
        title: typeof res.title === "string" ? res.title : "",
        texts,
        caption: typeof res.caption === "string" ? res.caption : "",
        hashtags: tags,
      });
    } catch (e) {
      const msg = e instanceof Error ? e.message.toLowerCase() : "";
      setErr(
        msg.includes("rate") || msg.includes("limit")
          ? "AI đang bận (giới hạn lượt dùng). Hãy thử lại sau ít phút."
          : "AI chưa tạo được kịch bản. Hãy thử lại hoặc đổi chủ đề.",
      );
    } finally {
      setBusy(false);
    }
  };

  return (
    <fieldset className="card tvm-panel tvm-fieldset" disabled={disabled || busy}>
      <span className="text-label">✨ Kịch bản bằng AI</span>
      <textarea
        className="input tvm-textarea"
        rows={2}
        maxLength={300}
        value={topic}
        placeholder="Chủ đề, ví dụ: 5 mẹo tiết kiệm tiền cho sinh viên"
        onChange={(e) => setTopic(e.target.value)}
      />
      <div className="tvm-row-wrap">
        <select className="input tvm-select" value={tone} onChange={(e) => setTone(e.target.value)} aria-label="Giọng điệu">
          {TONES.map((t) => (
            <option key={t} value={t}>{t}</option>
          ))}
        </select>
        <select className="input tvm-select" value={count} onChange={(e) => setCount(Number(e.target.value))} aria-label="Số cảnh">
          {[4, 5, 6, 7, 8, 10].map((n) => (
            <option key={n} value={n}>{n} cảnh</option>
          ))}
        </select>
      </div>
      <button type="button" className="button button-primary tvm-small" onClick={run}>
        {busy ? "Đang viết kịch bản…" : "Tạo kịch bản"}
      </button>
      <p className="tvm-tiny text-secondary">Sẽ thay các cảnh hiện tại — có nút hoàn tác.</p>
      {err && <p className="tvm-error">{err}</p>}
    </fieldset>
  );
}
