export type Anim = "fade" | "zoom" | "slide" | "pop" | "type";
export type TextPos = "top" | "center" | "bottom";
export type TextColor = "white" | "black" | "yellow";
export type TextStyle = "shadow" | "box";

export type Slide = {
  key: string;
  text: string;
  duration: number;
  bg: string;
  imageId: string | null;
  animation: Anim;
  textPos: TextPos;
  textColor: TextColor;
  textStyle: TextStyle;
  fontSize: number;
};

export const W = 720;
export const H = 1280;
const TRANSITION = 0.35;
const FONT =
  'system-ui, -apple-system, "Segoe UI", Roboto, "Helvetica Neue", Arial, "Apple Color Emoji", "Segoe UI Emoji", "Noto Color Emoji", sans-serif';

export const BACKGROUNDS: Array<{ id: string; name: string; colors: [string, string] }> = [
  { id: "neon", name: "Neon", colors: ["#ff0050", "#6a00f4"] },
  { id: "night", name: "Đêm", colors: ["#0f0c29", "#302b63"] },
  { id: "sunset", name: "Hoàng hôn", colors: ["#ff5f6d", "#ffc371"] },
  { id: "ocean", name: "Đại dương", colors: ["#2193b0", "#6dd5ed"] },
  { id: "mint", name: "Bạc hà", colors: ["#11998e", "#38ef7d"] },
  { id: "candy", name: "Kẹo ngọt", colors: ["#f953c6", "#b91d73"] },
  { id: "aqua", name: "Ngọc", colors: ["#25f4ee", "#0a6c74"] },
  { id: "peach", name: "Đào", colors: ["#ffecd2", "#fcb69f"] },
  { id: "dark", name: "Tối giản", colors: ["#141414", "#2b2b2b"] },
];

export const TEXT_COLORS: Record<TextColor, string> = {
  white: "#ffffff",
  black: "#111111",
  yellow: "#ffe14d",
};

export function bgById(id: string) {
  return BACKGROUNDS.find((b) => b.id === id) ?? BACKGROUNDS[0];
}

export function totalDuration(slides: Slide[]) {
  return slides.reduce((s, x) => s + x.duration, 0);
}

export function slideStart(slides: Slide[], index: number) {
  let t = 0;
  for (let i = 0; i < index && i < slides.length; i++) t += slides[i].duration;
  return t;
}

export function locate(slides: Slide[], t: number) {
  let acc = 0;
  for (let i = 0; i < slides.length; i++) {
    if (t < acc + slides[i].duration || i === slides.length - 1) {
      return { index: i, local: Math.max(0, Math.min(slides[i].duration, t - acc)) };
    }
    acc += slides[i].duration;
  }
  return { index: 0, local: 0 };
}

const easeOutCubic = (x: number) => 1 - Math.pow(1 - x, 3);
const easeOutBack = (x: number) => {
  const c1 = 1.70158;
  const c3 = c1 + 1;
  return 1 + c3 * Math.pow(x - 1, 3) + c1 * Math.pow(x - 1, 2);
};

function roundRectPath(ctx: CanvasRenderingContext2D, x: number, y: number, w: number, h: number, r: number) {
  const rr = Math.min(r, h / 2, w / 2);
  ctx.beginPath();
  ctx.moveTo(x + rr, y);
  ctx.lineTo(x + w - rr, y);
  ctx.quadraticCurveTo(x + w, y, x + w, y + rr);
  ctx.lineTo(x + w, y + h - rr);
  ctx.quadraticCurveTo(x + w, y + h, x + w - rr, y + h);
  ctx.lineTo(x + rr, y + h);
  ctx.quadraticCurveTo(x, y + h, x, y + h - rr);
  ctx.lineTo(x, y + rr);
  ctx.quadraticCurveTo(x, y, x + rr, y);
  ctx.closePath();
}

function wrap(ctx: CanvasRenderingContext2D, text: string, maxWidth: number) {
  const lines: string[] = [];
  for (const para of text.split("\n")) {
    const words = para.split(/\s+/).filter(Boolean);
    if (words.length === 0) {
      lines.push("");
      continue;
    }
    let line = "";
    for (const word of words) {
      const test = line ? `${line} ${word}` : word;
      if (ctx.measureText(test).width > maxWidth && line) {
        lines.push(line);
        line = word;
      } else {
        line = test;
      }
    }
    if (line) lines.push(line);
  }
  return lines;
}

function drawBackground(
  ctx: CanvasRenderingContext2D,
  slide: Slide,
  img: HTMLImageElement | undefined,
  local: number,
  alpha: number,
) {
  ctx.save();
  ctx.globalAlpha = alpha;
  if (img && img.complete && img.naturalWidth > 0) {
    const zoom = 1.02 + 0.08 * (local / Math.max(0.1, slide.duration));
    const scale = Math.max(W / img.naturalWidth, H / img.naturalHeight) * zoom;
    const dw = img.naturalWidth * scale;
    const dh = img.naturalHeight * scale;
    ctx.fillStyle = "#000";
    ctx.fillRect(0, 0, W, H);
    ctx.drawImage(img, (W - dw) / 2, (H - dh) / 2, dw, dh);
    const g = ctx.createLinearGradient(0, 0, 0, H);
    g.addColorStop(0, "rgba(0,0,0,0.25)");
    g.addColorStop(0.5, "rgba(0,0,0,0.1)");
    g.addColorStop(1, "rgba(0,0,0,0.45)");
    ctx.fillStyle = g;
    ctx.fillRect(0, 0, W, H);
  } else {
    const [a, b] = bgById(slide.bg).colors;
    const g = ctx.createLinearGradient(0, 0, W, H);
    g.addColorStop(0, a);
    g.addColorStop(1, b);
    ctx.fillStyle = g;
    ctx.fillRect(0, 0, W, H);
    // soft moving light blobs for depth
    const drift = local * 18;
    ctx.globalAlpha = alpha * 0.18;
    ctx.fillStyle = "#ffffff";
    ctx.beginPath();
    ctx.arc(W * 0.85 - drift, H * 0.18 + drift * 0.5, 260, 0, Math.PI * 2);
    ctx.fill();
    ctx.globalAlpha = alpha * 0.1;
    ctx.beginPath();
    ctx.arc(W * 0.1 + drift, H * 0.85 - drift * 0.4, 340, 0, Math.PI * 2);
    ctx.fill();
  }
  ctx.restore();
}

function drawText(ctx: CanvasRenderingContext2D, slide: Slide, local: number, outerAlpha: number) {
  if (!slide.text.trim()) return;
  const p = Math.min(1, local / 0.6);
  let alpha = 1;
  let scale = 1;
  let dy = 0;
  let visible = Number.POSITIVE_INFINITY;
  switch (slide.animation) {
    case "fade":
      alpha = easeOutCubic(p);
      break;
    case "zoom":
      alpha = easeOutCubic(p);
      scale = 0.7 + 0.3 * easeOutCubic(p);
      break;
    case "slide":
      alpha = easeOutCubic(p);
      dy = (1 - easeOutCubic(p)) * 140;
      break;
    case "pop":
      scale = Math.max(0.001, easeOutBack(Math.min(1, local / 0.45)));
      break;
    case "type":
      visible = Math.floor(local * 24);
      break;
  }

  const fs = slide.fontSize;
  ctx.save();
  ctx.font = `800 ${fs}px ${FONT}`;
  const lines = wrap(ctx, slide.text, W * 0.84);
  const lineH = fs * 1.25;
  const blockH = lines.length * lineH;
  let cy = H / 2;
  if (slide.textPos === "top") cy = Math.max(H * 0.2, blockH / 2 + 140);
  if (slide.textPos === "bottom") cy = Math.min(H * 0.72, H - blockH / 2 - 260);

  ctx.globalAlpha = outerAlpha * alpha;
  ctx.translate(W / 2, cy + dy);
  ctx.scale(scale, scale);
  ctx.textAlign = "center";
  ctx.textBaseline = "middle";
  const color = TEXT_COLORS[slide.textColor];
  let remaining = visible;

  lines.forEach((line, i) => {
    const y = -blockH / 2 + lineH * (i + 0.5);
    let shown = line;
    if (Number.isFinite(remaining)) {
      const chars = Array.from(line);
      shown = chars.slice(0, Math.max(0, remaining)).join("");
      remaining -= chars.length + 1;
    }
    if (!shown) return;
    if (slide.textStyle === "box") {
      const w = ctx.measureText(shown).width + fs * 0.6;
      const h = lineH * 1.02;
      ctx.fillStyle = slide.textColor === "black" ? "rgba(255,255,255,0.95)" : "rgba(0,0,0,0.6)";
      roundRectPath(ctx, -w / 2, y - h / 2, w, h, fs * 0.22);
      ctx.fill();
      ctx.fillStyle = color;
      ctx.fillText(shown, 0, y + fs * 0.04);
    } else {
      ctx.shadowColor = slide.textColor === "black" ? "rgba(255,255,255,0.55)" : "rgba(0,0,0,0.6)";
      ctx.shadowBlur = fs * 0.28;
      ctx.shadowOffsetY = fs * 0.04;
      ctx.lineJoin = "round";
      ctx.lineWidth = fs * 0.09;
      ctx.strokeStyle = slide.textColor === "black" ? "rgba(255,255,255,0.6)" : "rgba(0,0,0,0.45)";
      ctx.strokeText(shown, 0, y);
      ctx.shadowColor = "transparent";
      ctx.fillStyle = color;
      ctx.fillText(shown, 0, y);
    }
  });
  ctx.restore();
}

function drawSlide(
  ctx: CanvasRenderingContext2D,
  slide: Slide,
  images: Map<string, HTMLImageElement>,
  local: number,
  alpha: number,
) {
  const img = slide.imageId ? images.get(slide.imageId) : undefined;
  drawBackground(ctx, slide, img, local, alpha);
  drawText(ctx, slide, local, alpha);
}

export function drawFrame(
  ctx: CanvasRenderingContext2D,
  slides: Slide[],
  images: Map<string, HTMLImageElement>,
  t: number,
) {
  ctx.save();
  ctx.globalAlpha = 1;
  ctx.fillStyle = "#000";
  ctx.fillRect(0, 0, W, H);
  ctx.restore();
  if (slides.length === 0) return;
  const { index, local } = locate(slides, t);
  const cur = slides[index];
  if (index > 0 && local < TRANSITION) {
    const prev = slides[index - 1];
    drawSlide(ctx, prev, images, prev.duration, 1);
    drawSlide(ctx, cur, images, local, local / TRANSITION);
  } else {
    drawSlide(ctx, cur, images, local, 1);
  }
}
